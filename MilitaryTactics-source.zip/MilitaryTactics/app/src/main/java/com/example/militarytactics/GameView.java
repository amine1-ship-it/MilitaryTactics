package com.example.militarytactics;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/** Offline, procedurally rendered top-down tactical skirmish. */
public class GameView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random(7341);
    private final ArrayList<Soldier> soldiers = new ArrayList<Soldier>();
    private final ArrayList<Bullet> bullets = new ArrayList<Bullet>();
    private final ArrayList<Tank> tanks = new ArrayList<Tank>();
    private final ArrayList<Blast> blasts = new ArrayList<Blast>();
    private final Point[] points = {new Point(350, 255, "A"), new Point(750, 480, "B"), new Point(1160, 260, "C")};
    private final RectF[] buildings = {
        new RectF(475, 145, 550, 210), new RectF(610, 155, 690, 225),
        new RectF(860, 570, 940, 640), new RectF(1010, 575, 1090, 645),
        new RectF(455, 610, 535, 675), new RectF(630, 625, 700, 690),
        new RectF(1240, 430, 1310, 495), new RectF(170, 560, 240, 625)
    };
    private final float worldW = 1500, worldH = 900;
    private float screenW, screenH, camX, camY, moveX, moveY;
    private float joyX, joyY, aimX = 1, aimY = 0;
    private float playerX = 220, playerY = 420, playerHp = 100;
    private float fireCooldown, reloadTimer, elapsed, bleedTimer, respawnTimer, hitFlash;
    private int ammo = 30, ticketsBlue = 300, ticketsRed = 300, playerClass = 0;
    private long lastTime;
    private boolean running = true, started, paused, ended, victory, firing, aiming, joystick;
    private int joyPointer = -1, firePointer = -1, aimPointer = -1;
    private Tank controlledTank;
    private final String[] classes = {"RIFLEMAN", "MACHINE GUNNER", "SNIPER", "ANTI-TANK"};

    public GameView(Context context) {
        super(context);
        setFocusable(true);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void pauseLoop() { running = false; }
    public void resumeLoop() { running = true; lastTime = 0; invalidate(); }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        screenW = getWidth(); screenH = getHeight();
        if (!running || screenW <= 0 || screenH <= 0) return;
        long now = System.nanoTime();
        float dt = lastTime == 0 ? 0.016f : Math.min(0.04f, (now - lastTime) / 1000000000f);
        lastTime = now;
        if (started && !paused && !ended) update(dt);
        if (!started) drawMenu(canvas);
        else { drawWorld(canvas); drawHud(canvas); if (paused) drawOverlay(canvas, "PAUSED", "Tap RESUME to continue"); if (ended) drawOverlay(canvas, victory ? "VICTORY" : "DEFEAT", "Match finished"); }
        if (running) postInvalidateDelayed(16);
    }

    private void startGame() {
        started = true; paused = false; ended = false; victory = false;
        playerX = 220; playerY = 420; playerHp = 100; ammo = capacity();
        ticketsBlue = 300; ticketsRed = 300; elapsed = bleedTimer = respawnTimer = fireCooldown = reloadTimer = 0;
        controlledTank = null; bullets.clear(); soldiers.clear(); tanks.clear(); blasts.clear(); firing = aiming = joystick = false;
        joyPointer = firePointer = aimPointer = -1; moveX = moveY = 0;
        for (int i = 0; i < 14; i++) {
            soldiers.add(new Soldier(170 + random.nextInt(230), 180 + random.nextInt(520), 0, i % 4));
            soldiers.add(new Soldier(930 + random.nextInt(340), 150 + random.nextInt(560), 1, i % 4));
        }
        tanks.add(new Tank(300, 690, 0)); tanks.add(new Tank(1210, 690, 1));
        for (Point point : points) { point.owner = -1; point.progress = 0; }
    }

    private void update(float dt) {
        elapsed += dt; fireCooldown = Math.max(0, fireCooldown - dt); hitFlash = Math.max(0, hitFlash - dt);
        if (reloadTimer > 0) { reloadTimer -= dt; if (reloadTimer <= 0) ammo = capacity(); }
        if (respawnTimer > 0) {
            respawnTimer -= dt;
            if (respawnTimer <= 0) { playerHp = 100; playerX = 220; playerY = 420; ammo = capacity(); controlledTank = null; }
        }
        if (controlledTank != null && !controlledTank.alive) { controlledTank = null; playerHp = 0; respawnTimer = Math.max(respawnTimer, 4); }
        if (controlledTank != null) {
            float nx = controlledTank.x + moveX * 90 * dt, ny = controlledTank.y + moveY * 90 * dt;
            moveUnit(controlledTank, nx, ny);
            if (Math.abs(moveX) + Math.abs(moveY) > 0.1f) controlledTank.angle = (float)Math.atan2(moveY, moveX);
            controlledTank.turret = (float)Math.atan2(aimY, aimX);
        } else if (playerHp > 0 && respawnTimer <= 0) {
            movePoint(playerX, playerY, moveX * 145 * dt, moveY * 145 * dt);
        }
        if (firing && fireCooldown <= 0 && ammo > 0 && respawnTimer <= 0 && (playerHp > 0 || controlledTank != null)) {
            float x = playerWorldX(), y = playerWorldY();
            float speed = controlledTank == null ? 500 : 370;
            float damage = controlledTank == null ? damageForClass() : 70;
            float range = controlledTank == null ? rangeForClass() : 600;
            bullets.add(new Bullet(x + aimX * 16, y + aimY * 16, aimX * speed, aimY * speed, 0, damage, range));
            ammo--; fireCooldown = controlledTank == null ? rateForClass() : 1.8f;
        }
        if (ammo <= 0 && reloadTimer <= 0) reloadTimer = controlledTank != null ? 2.8f : reloadForClass();

        for (Soldier s : soldiers) {
            if (!s.alive) { s.respawn -= dt; if (s.respawn <= 0) { s.alive = true; s.hp = 100; s.x = s.team == 0 ? 190 + random.nextInt(150) : 1070 + random.nextInt(150); s.y = 190 + random.nextInt(510); s.cool = 0.2f + random.nextFloat(); } continue; }
            float px = playerWorldX(), py = playerWorldY();
            Soldier target = nearestSoldier(s.x, s.y, 1 - s.team, 340);
            boolean targetPlayer = s.team == 1 && playerHp > 0 && respawnTimer <= 0 && dist(s.x, s.y, px, py) < 340 && (target == null || dist(s.x, s.y, px, py) < dist(s.x, s.y, target.x, target.y));
            float tx, ty, td;
            if (targetPlayer) { tx = px; ty = py; td = dist(s.x, s.y, tx, ty); }
            else if (target != null) { tx = target.x; ty = target.y; td = dist(s.x, s.y, tx, ty); }
            else { Point point = nearestPoint(s.x, s.y); tx = point.x; ty = point.y; td = dist(s.x, s.y, tx, ty); }
            if ((target != null || targetPlayer) && td < 340) {
                if (td > (s.type == 2 ? 195 : 105)) moveSoldier(s, (tx - s.x) / Math.max(1, td) * 42 * dt, (ty - s.y) / Math.max(1, td) * 42 * dt);
                else { s.cool -= dt; if (s.cool <= 0) { float d = Math.max(1, td); float spread = s.type == 2 ? 0.015f : 0.065f; float vx = (tx - s.x) / d + (random.nextFloat() - .5f) * spread; float vy = (ty - s.y) / d + (random.nextFloat() - .5f) * spread; float speed = s.type == 2 ? 400 : 300; bullets.add(new Bullet(s.x, s.y, vx * speed, vy * speed, s.team, s.type == 2 ? 42 : 17, s.type == 2 ? 520 : 310)); s.cool = s.type == 2 ? 1.65f : (s.type == 1 ? .55f : .85f); } }
            } else if (td > 35) moveSoldier(s, (tx - s.x) / Math.max(1, td) * 31 * dt, (ty - s.y) / Math.max(1, td) * 31 * dt);
        }
        for (Tank tank : tanks) {
            if (!tank.alive) continue;
            Soldier target = nearestSoldier(tank.x, tank.y, 1 - tank.team, 480);
            float tx, ty, td;
            boolean targetPlayer = tank.team == 1 && playerHp > 0 && respawnTimer <= 0 && dist(tank.x, tank.y, playerWorldX(), playerWorldY()) < 440 && (target == null || dist(tank.x,tank.y,playerWorldX(),playerWorldY()) < dist(tank.x,tank.y,target.x,target.y));
            if (targetPlayer) { tx = playerWorldX(); ty = playerWorldY(); } else if (target != null) { tx = target.x; ty = target.y; } else { Point pt = nearestPoint(tank.x, tank.y); tx=pt.x; ty=pt.y; }
            td = dist(tank.x, tank.y, tx, ty); tank.turret = (float)Math.atan2(ty - tank.y, tx - tank.x);
            if (tank != controlledTank && (target != null || targetPlayer)) {
                if (td > 190) moveUnit(tank, tank.x + (tx - tank.x) / Math.max(1,td) * 22 * dt, tank.y + (ty - tank.y) / Math.max(1,td) * 22 * dt);
                else { tank.cool -= dt; if (tank.cool <= 0) { bullets.add(new Bullet(tank.x, tank.y, (tx-tank.x)/Math.max(1,td)*300, (ty-tank.y)/Math.max(1,td)*300, tank.team, 50, 500)); tank.cool=2.4f; } }
            }
        }

        Iterator<Bullet> bulletIt = bullets.iterator();
        while (bulletIt.hasNext()) {
            Bullet b = bulletIt.next(); b.x += b.vx * dt; b.y += b.vy * dt; b.travelled += (float)Math.hypot(b.vx, b.vy) * dt;
            if (b.travelled >= b.range || b.x < 0 || b.y < 0 || b.x > worldW || b.y > worldH || blocked(b.x, b.y)) { bulletIt.remove(); continue; }
            boolean hit = false;
            if (b.team != 0 && playerHp > 0 && respawnTimer <= 0 && dist(b.x,b.y,playerWorldX(),playerWorldY()) < (controlledTank == null ? 17 : 28)) {
                if (controlledTank != null) { controlledTank.hp -= b.damage; if (controlledTank.hp <= 0) destroyTank(controlledTank); }
                else { playerHp -= b.damage; hitFlash = .15f; if (playerHp <= 0) { playerHp = 0; ticketsBlue = Math.max(0, ticketsBlue - 1); respawnTimer = 4; } }
                hit = true;
            }
            if (!hit) for (Soldier s : soldiers) if (s.alive && s.team != b.team && dist(b.x,b.y,s.x,s.y) < 14) {
                s.hp -= b.damage; hit = true; if (s.hp <= 0) { s.alive=false; s.respawn=5; awardDeathTicket(s.team); blasts.add(new Blast(s.x,s.y)); } break;
            }
            if (!hit) for (Tank t : tanks) if (t.alive && t.team != b.team && dist(b.x,b.y,t.x,t.y) < 27) {
                t.hp -= b.damage; hit = true; if (t.hp <= 0) destroyTank(t); break;
            }
            if (hit) bulletIt.remove();
        }

        for (Point pt : points) {
            int blue = 0, red = 0;
            if (playerHp > 0 && respawnTimer <= 0 && dist(playerWorldX(),playerWorldY(),pt.x,pt.y) < 90) blue++;
            for (Soldier s : soldiers) if (s.alive && dist(s.x,s.y,pt.x,pt.y) < 82) { if (s.team == 0) blue++; else red++; }
            if (blue > 0 && red == 0) { pt.progress = Math.min(100, pt.progress + dt * 18); if (pt.progress >= 100) pt.owner=0; }
            else if (red > 0 && blue == 0) { pt.progress = Math.max(-100, pt.progress - dt * 18); if (pt.progress <= -100) pt.owner=1; }
        }
        bleedTimer += dt;
        if (bleedTimer >= 5) { bleedTimer=0; int blue=0,red=0; for(Point pt:points){if(pt.owner==0)blue++;if(pt.owner==1)red++;} if(blue>red)ticketsRed=Math.max(0,ticketsRed-1); else if(red>blue)ticketsBlue=Math.max(0,ticketsBlue-1); }
        for (Blast blast : blasts) blast.life -= dt;
        for (int i=blasts.size()-1;i>=0;i--) if(blasts.get(i).life<=0)blasts.remove(i);
        if (ticketsBlue <= 0 || ticketsRed <= 0 || elapsed >= 600) { ended=true; victory=ticketsBlue>ticketsRed; }
        float followX = playerWorldX(), followY = playerWorldY(); camX=clamp(followX-screenW/2,0,Math.max(0,worldW-screenW)); camY=clamp(followY-screenH/2,0,Math.max(0,worldH-screenH));
    }

    private void awardDeathTicket(int team) { if (team == 0) ticketsBlue = Math.max(0,ticketsBlue-1); else ticketsRed = Math.max(0,ticketsRed-1); }
    private void destroyTank(Tank tank) { if (!tank.alive) return; tank.alive=false; if(tank.team==0)ticketsBlue=Math.max(0,ticketsBlue-5);else ticketsRed=Math.max(0,ticketsRed-5);blasts.add(new Blast(tank.x,tank.y)); }
    private float playerWorldX() { return controlledTank == null ? playerX : controlledTank.x; }
    private float playerWorldY() { return controlledTank == null ? playerY : controlledTank.y; }
    private Soldier nearestSoldier(float x,float y,int team,float radius) { Soldier best=null;float bd=radius;for(Soldier s:soldiers)if(s.alive&&s.team==team){float d=dist(x,y,s.x,s.y);if(d<bd){bd=d;best=s;}}return best; }
    private Point nearestPoint(float x,float y) { Point best=points[0];float d=Float.MAX_VALUE;for(Point pt:points){float nd=dist(x,y,pt.x,pt.y);if(nd<d){d=nd;best=pt;}}return best; }
    private boolean blocked(float x,float y) { for(RectF r:buildings)if(r.contains(x,y))return true;return false; }
    private void movePoint(float x,float y,float dx,float dy) { float nx=clamp(x+dx,18,worldW-18),ny=clamp(y+dy,18,worldH-18);if(!blocked(nx,y))playerX=nx;if(!blocked(playerX,ny))playerY=ny; }
    private void moveSoldier(Soldier s,float dx,float dy) { float nx=clamp(s.x+dx,18,worldW-18),ny=clamp(s.y+dy,18,worldH-18);if(!blocked(nx,s.y))s.x=nx;if(!blocked(s.x,ny))s.y=ny; }
    private void moveUnit(Tank t,float nx,float ny) { nx=clamp(nx,28,worldW-28);ny=clamp(ny,28,worldH-28);if(!blocked(nx,t.y))t.x=nx;if(!blocked(t.x,ny))t.y=ny; }
    private int capacity() { return playerClass==1?60:playerClass==2?8:playerClass==3?5:30; }
    private int damageForClass() { return playerClass==2?55:playerClass==3?72:playerClass==1?13:24; }
    private float rateForClass() { return playerClass==1?.12f:playerClass==2?.85f:playerClass==3?1.25f:.24f; }
    private float reloadForClass() { return playerClass==1?3f:playerClass==2?2.4f:playerClass==3?3.1f:2f; }
    private float rangeForClass() { return playerClass==2?600:playerClass==3?520:420; }

    private void drawWorld(Canvas c) {
        c.drawColor(0xff61754d); c.save(); c.translate(-camX,-camY);
        p.setColor(0xff77735d); c.drawRect(0,360,worldW,435,p); c.drawRect(680,0,750,worldH,p);
        p.setColor(0xff527d91);c.drawRect(0,82,worldW,112,p); p.setColor(0xffb0a887);p.setStrokeWidth(2);for(int x=0;x<worldW;x+=48)c.drawLine(x,398,x+25,398,p);
        for(int i=0;i<65;i++){float x=(i*139)%1450,y=(i*83)%850;p.setColor(i%2==0?0xff788f5c:0xff8a9b66);c.drawCircle(x,y,9+(i%4)*2,p);}
        for(RectF b:buildings){p.setColor(0xff555950);c.drawRect(b.left+4,b.top+5,b.right+4,b.bottom+5,p);p.setColor(0xff8b897d);c.drawRect(b,p);p.setColor(0xff4b514b);c.drawRect(b.left+8,b.top+8,b.right-8,b.bottom-8,p);p.setColor(0xffb0a78b);c.drawRect(b.centerX()-5,b.top+8,b.centerX()+5,b.bottom-8,p);}
        for(Point pt:points){int col=pt.owner==0?0xff4d9cff:pt.owner==1?0xffee5757:0xffe4dfc8;p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(col);c.drawCircle(pt.x,pt.y,47,p);p.setStyle(Paint.Style.FILL);p.setColor(0x55404040);c.drawCircle(pt.x,pt.y,35,p);p.setColor(Color.WHITE);p.setTextSize(25);p.setFakeBoldText(true);c.drawText(pt.name,pt.x-8,pt.y+9,p);p.setFakeBoldText(false);if(pt.owner==-1){p.setColor(0xffded8b4);c.drawRect(pt.x-30,pt.y+53,pt.x+30,pt.y+58,p);p.setColor(0xff5b9dce);c.drawRect(pt.x-30,pt.y+53,pt.x-30+60*Math.abs(pt.progress)/100,pt.y+58,p);}}
        for(Soldier s:soldiers)if(s.alive)drawSoldier(c,s.x,s.y,s.team,s.hp,s.type);
        for(Tank t:tanks)if(t.alive)drawTank(c,t);
        if(playerHp>0&&respawnTimer<=0&&controlledTank==null)drawSoldier(c,playerX,playerY,0,playerHp,playerClass);
        for(Bullet b:bullets){p.setColor(b.team==0?0xffffe49b:0xffff7777);p.setStrokeWidth(3);c.drawLine(b.x,b.y,b.x-b.vx*.025f,b.y-b.vy*.025f,p);}
        for(Blast b:blasts){p.setColor(0x66ff9a25);c.drawCircle(b.x,b.y,(1-b.life/.55f)*47,p);p.setColor(0xffffb23e);c.drawCircle(b.x,b.y,(1-b.life/.55f)*22,p);}
        c.restore();
    }
    private void drawSoldier(Canvas c,float x,float y,int team,float hp,int type){int color=team==0?0xff4f9af0:0xffe34c4c;p.setColor(0xff202720);c.drawCircle(x,y,14,p);p.setColor(color);c.drawCircle(x,y,11,p);p.setColor(0xff202820);p.setStrokeWidth(type==1?6:4);c.drawLine(x+1,y,x+15,y-5,p);p.setColor(0xff202820);c.drawRect(x-13,y-21,x+13,y-18,p);p.setColor(0xff62db77);c.drawRect(x-12,y-20,x-12+24*Math.max(0,hp)/100f,y-19,p);}
    private void drawTank(Canvas c,Tank t){float x=t.x,y=t.y;c.save();c.rotate((float)Math.toDegrees(t.angle),x,y);p.setColor(0xff252d29);c.drawRoundRect(new RectF(x-28,y-21,x+28,y+21),4,4,p);p.setColor(t.team==0?0xff326e9e:0xffa63e3e);c.drawRoundRect(new RectF(x-23,y-15,x+23,y+15),4,4,p);c.restore();c.save();c.rotate((float)Math.toDegrees(t.turret),x,y);p.setColor(0xff78866c);c.drawCircle(x,y,12,p);p.setStrokeWidth(8);c.drawLine(x,y,x+34,y,p);c.restore();p.setColor(0xff202820);c.drawRect(x-23,y-31,x+23,y-28,p);p.setColor(0xff62db77);c.drawRect(x-23,y-31,x-23+46*Math.max(0,t.hp)/180f,y-28,p);}

    private void drawHud(Canvas c) {
        p.setColor(0xdd111a14);c.drawRoundRect(new RectF(12,10,screenW-12,58),12,12,p);p.setTextSize(19);p.setFakeBoldText(true);p.setColor(0xff7db6ff);c.drawText("BLUE  "+ticketsBlue,25,40,p);p.setColor(0xffff8585);c.drawText("RED  "+ticketsRed,screenW-125,40,p);p.setColor(Color.WHITE);p.setTextSize(14);p.setFakeBoldText(false);int remaining=Math.max(0,600-(int)elapsed);String time=String.format(java.util.Locale.US,"%02d:%02d",remaining/60,remaining%60);c.drawText(time,screenW/2-18,28,p);for(int i=0;i<3;i++){Point pt=points[i];p.setColor(pt.owner==0?0xff4289e8:pt.owner==1?0xffe34d4d:Color.WHITE);c.drawCircle(screenW/2-20+i*20,43,6,p);}
        p.setColor(0xcc101713);c.drawRoundRect(new RectF(12,screenH-62,235,screenH-10),11,11,p);p.setColor(Color.WHITE);p.setTextSize(13);c.drawText(controlledTank==null?classes[playerClass]:"TANK DRIVER",23,screenH-39,p);String health=controlledTank==null?"HP "+Math.max(0,(int)playerHp):"TANK "+Math.max(0,(int)controlledTank.hp);c.drawText(health+"  AMMO "+ammo,23,screenH-20,p);
        float jx=92,jy=screenH-132;p.setColor(0x55333333);c.drawCircle(jx,jy,49,p);p.setColor(0x99eeeeee);c.drawCircle(jx+moveX*27,jy+moveY*27,19,p);
        // Aim pad is a distinct large target area, with fire/reload/switch buttons on the far right.
        p.setColor(0x44333333);c.drawCircle(screenW-245,screenH-180,43,p);p.setColor(0xffd7dfd4);c.drawCircle(screenW-245+aimX*21,screenH-180+aimY*21,11,p);
        button(c,screenW-86,screenH-105,48,"FIRE",0xffc74b43);button(c,screenW-194,screenH-58,30,"R",0xff557c9b);button(c,screenW-270,screenH-58,30,"SW",0xff557c9b);button(c,screenW-340,screenH-58,30,"VEH",0xff67814d);button(c,screenW-48,78,26,paused?">":"II",0xff454b4a);
        drawMinimap(c);
        if(respawnTimer>0){p.setColor(Color.WHITE);p.setTextSize(20);p.setFakeBoldText(true);p.setTextAlign(Paint.Align.CENTER);c.drawText("RESPAWNING "+(int)Math.ceil(respawnTimer),screenW/2,screenH*.72f,p);p.setTextAlign(Paint.Align.LEFT);p.setFakeBoldText(false);}
        if(hitFlash>0){p.setColor(0x44ff0000);c.drawRect(0,0,screenW,screenH,p);}
    }
    private void drawMinimap(Canvas c){float mw=116,mh=70,mx=screenW/2-mw/2,my=62;p.setColor(0xc9162119);c.drawRoundRect(new RectF(mx,my,mx+mw,my+mh),7,7,p);for(Point pt:points){p.setColor(pt.owner==0?0xff4289e8:pt.owner==1?0xffe34d4d:Color.WHITE);c.drawCircle(mx+pt.x/worldW*mw,my+pt.y/worldH*mh,3,p);}for(Soldier s:soldiers)if(s.alive){p.setColor(s.team==0?0xff65aaff:0xffff7777);c.drawCircle(mx+s.x/worldW*mw,my+s.y/worldH*mh,1.8f,p);}for(Tank t:tanks)if(t.alive){p.setColor(t.team==0?0xff65aaff:0xffff7777);c.drawCircle(mx+t.x/worldW*mw,my+t.y/worldH*mh,3,p);}p.setColor(Color.WHITE);c.drawCircle(mx+playerWorldX()/worldW*mw,my+playerWorldY()/worldH*mh,3,p);}
    private void button(Canvas c,float x,float y,float radius,String text,int color){p.setColor(0x99000000);c.drawCircle(x,y,radius+2,p);p.setColor(color);c.drawCircle(x,y,radius,p);p.setColor(Color.WHITE);p.setTextSize(text.length()>3?11:14);p.setFakeBoldText(true);c.drawText(text,x-p.measureText(text)/2,y+5,p);p.setFakeBoldText(false);}
    private void drawMenu(Canvas c){c.drawColor(0xff263a2c);p.setTextAlign(Paint.Align.CENTER);p.setColor(0xffe5ebd8);p.setTextSize(Math.min(38,screenW/15));p.setFakeBoldText(true);c.drawText("MILITARY TACTICS",screenW/2,screenH*.27f,p);p.setTextSize(17);p.setFakeBoldText(false);c.drawText("OFFLINE TOP-DOWN TACTICAL COMBAT",screenW/2,screenH*.37f,p);button(c,screenW/2,screenH*.56f,48,"PLAY",0xff3c8a58);button(c,screenW/2,screenH*.76f,38,"CLASS",0xff557c9b);c.drawText("CLASS: "+classes[playerClass],screenW/2,screenH*.9f,p);p.setTextAlign(Paint.Align.LEFT);}
    private void drawOverlay(Canvas c,String title,String subtitle){p.setColor(0xbb101610);c.drawRect(0,0,screenW,screenH,p);p.setTextAlign(Paint.Align.CENTER);p.setColor(Color.WHITE);p.setTextSize(38);p.setFakeBoldText(true);c.drawText(title,screenW/2,screenH*.33f,p);p.setTextSize(17);p.setFakeBoldText(false);c.drawText(subtitle,screenW/2,screenH*.43f,p);button(c,screenW/2,screenH*.59f,46,ended?"RESTART":"RESUME",0xff3c8a58);button(c,screenW/2,screenH*.77f,38,"MENU",0xff557c9b);p.setTextAlign(Paint.Align.LEFT);}

    @Override public boolean onTouchEvent(MotionEvent event) {
        final int action=event.getActionMasked(), index=event.getActionIndex(), id=event.getPointerId(index);
        if(!started){if(action==MotionEvent.ACTION_UP){float x=event.getX(),y=event.getY();if(y>screenH*.68f){playerClass=(playerClass+1)%4;ammo=capacity();invalidate();}else startGame();}return true;}
        if(paused||ended){if(action==MotionEvent.ACTION_UP){float y=event.getY();if(y>screenH*.68f){started=false;paused=false;ended=false;controlledTank=null;}else if(ended)startGame();else paused=false;}return true;}
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN){float x=event.getX(index),y=event.getY(index);
            if(x>screenW-82&&y<118){paused=true;return true;}
            if(x<screenW*.34f&&y>screenH*.48f){joyPointer=id;joystick=true;joyX=x;joyY=y;updateJoy(x,y);}
            else if(x>screenW-130&&y>screenH-165){firePointer=id;firing=true;}
            else if(x>screenW-225&&y>screenH-95){if(ammo<capacity()&&reloadTimer<=0)reloadTimer=reloadForClass();}
            else if(x>screenW-310&&y>screenH-100){playerClass=(playerClass+1)%4;ammo=capacity();reloadTimer=0;}
            else if(x>screenW-390&&y>screenH-100){toggleVehicle();}
            else if(x>screenW*.52f&&y>screenH*.35f){aimPointer=id;aiming=true;updateAim(x,y);}
            else { updateAim(x,y); }
        } else if(action==MotionEvent.ACTION_MOVE){
            if(joyPointer!=-1){int k=event.findPointerIndex(joyPointer);if(k>=0)updateJoy(event.getX(k),event.getY(k));}
            if(aimPointer!=-1){int k=event.findPointerIndex(aimPointer);if(k>=0)updateAim(event.getX(k),event.getY(k));}
        } else if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_POINTER_UP||action==MotionEvent.ACTION_CANCEL){
            if(id==joyPointer){joyPointer=-1;joystick=false;moveX=moveY=0;}
            if(id==firePointer){firePointer=-1;firing=false;}
            if(id==aimPointer){aimPointer=-1;aiming=false;}
            if(action==MotionEvent.ACTION_CANCEL){joyPointer=firePointer=aimPointer=-1;joystick=firing=aiming=false;moveX=moveY=0;}
        }
        return true;
    }
    private void updateJoy(float x,float y){float dx=x-joyX,dy=y-joyY,d=(float)Math.hypot(dx,dy);if(d>42){dx*=42/d;dy*=42/d;}moveX=dx/42;moveY=dy/42;}
    private void updateAim(float x,float y){float screenPX=playerWorldX()-camX,screenPY=playerWorldY()-camY;float dx=x-screenPX,dy=y-screenPY,d=(float)Math.hypot(dx,dy);if(d>3){aimX=dx/d;aimY=dy/d;if(controlledTank!=null)controlledTank.turret=(float)Math.atan2(aimY,aimX);}}
    private void toggleVehicle(){if(controlledTank!=null){playerX=clamp(controlledTank.x+42,18,worldW-18);playerY=controlledTank.y;controlledTank=null;return;}if(playerHp<=0||respawnTimer>0)return;Tank nearest=null;float nd=78;for(Tank t:tanks)if(t.team==0&&t.alive){float d=dist(playerX,playerY,t.x,t.y);if(d<nd){nd=d;nearest=t;}}if(nearest!=null){controlledTank=nearest;ammo=Math.min(ammo,capacity());}}
    private float clamp(float v,float min,float max){return Math.max(min,Math.min(max,v));}
    private float dist(float x,float y,float xx,float yy){return (float)Math.hypot(x-xx,y-yy);}

    private static class Soldier {float x,y,hp=100,cool,respawn;int team,type;boolean alive=true;Soldier(float x,float y,int team,int type){this.x=x;this.y=y;this.team=team;this.type=type;cool=.2f;}}
    private static class Bullet {float x,y,vx,vy,damage,range,travelled;int team;Bullet(float x,float y,float vx,float vy,int team,float damage,float range){this.x=x;this.y=y;this.vx=vx;this.vy=vy;this.team=team;this.damage=damage;this.range=range;}}
    private static class Tank {float x,y,hp=180,angle,turret,cool=1;int team;boolean alive=true;Tank(float x,float y,int team){this.x=x;this.y=y;this.team=team;}}
    private static class Point {float x,y,progress;String name;int owner=-1;Point(float x,float y,String name){this.x=x;this.y=y;this.name=name;}}
    private static class Blast {float x,y,life=.55f;Blast(float x,float y){this.x=x;this.y=y;}}
}
